
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import pandas as pd

# Create a DataFrame with DCA strategies comparison data
data = {
    'Strategy': ['Basic DCA', 'Value-Averaging DCA', 'Technical DCA', 'Dynamic DCA', 'Algorithmic DCA', 'Multi-Asset DCA', 'Threshold-Based DCA', 'Event-Triggered DCA'],
    'Complexity': [1, 3, 3, 4, 5, 2, 2, 3],
    'Risk Management': [2, 4, 4, 4, 5, 3, 3, 4],
    'Customization': [1, 4, 4, 4, 5, 3, 3, 4],
    'Automation': [1, 3, 3, 4, 5, 2, 2, 3],
    'Suitability for Beginners': [5, 3, 3, 2, 1, 4, 4, 3]
}

df = pd.DataFrame(data)

# Initialize the Dash app
app = dash.Dash(__name__)

# Create the radar chart
fig = px.line_polar(df, r=df.columns[1:], theta='Strategy', line_close=True, title='Comparison of Advanced DCA Strategies')

# Define the layout of the dashboard
app.layout = html.Div([
    html.H1("Advanced DCA Strategies for Bitcoin Investment"),
    dcc.Dropdown(
        id='strategy-dropdown',
        options=[{'label': strategy, 'value': strategy} for strategy in df['Strategy']],
        value='Basic DCA',
        multi=True
    ),
    dcc.Graph(id='radar-chart', figure=fig),
    html.Div(id='description')
])

# Define callback to update the radar chart based on selected strategies
@app.callback(
    dash.dependencies.Output('radar-chart', 'figure'),
    [dash.dependencies.Input('strategy-dropdown', 'value')]
)
def update_chart(selected_strategies):
    filtered_df = df[df['Strategy'].isin(selected_strategies)]
    fig = px.line_polar(filtered_df, r=filtered_df.columns[1:], theta='Strategy', line_close=True, title='Comparison of Advanced DCA Strategies')
    return fig

# Define callback to update the description based on selected strategies
@app.callback(
    dash.dependencies.Output('description', 'children'),
    [dash.dependencies.Input('strategy-dropdown', 'value')]
)
def update_description(selected_strategies):
    descriptions = {
        'Basic DCA': 'Investing a fixed amount at regular intervals.',
        'Value-Averaging DCA': 'Investing more when prices drop and less when prices rise.',
        'Technical DCA': 'Using technical indicators to adjust DCA schedule.',
        'Dynamic DCA': 'Adjusting DCA amount based on market volatility.',
        'Algorithmic DCA': 'Using bots or scripts to automate DCA.',
        'Multi-Asset DCA': 'DCA into a basket of assets.',
        'Threshold-Based DCA': 'Investing when the price drops by a certain percentage.',
        'Event-Triggered DCA': 'Investing based on macro or crypto-specific events.'
    }
    return [html.P(f"{strategy}: {descriptions[strategy]}") for strategy in selected_strategies]

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
